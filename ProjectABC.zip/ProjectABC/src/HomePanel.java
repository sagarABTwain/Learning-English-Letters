//import java.applet.Applet;
import java.applet.AudioClip;
//import java.awt.BorderLayout;
import java.awt.Graphics;
import java.awt.Image;
//import java.awt.event.ActionEvent;
//import java.awt.event.ActionListener;
//import java.net.URL;
//
//import javax.swing.Icon;
import javax.swing.ImageIcon;
//import javax.swing.JButton;
//import javax.swing.JFrame;
//import javax.swing.JLabel;
//import javax.swing.JMenuBar;
import javax.swing.JPanel;

//import sun.nio.ch.WindowsAsynchronousChannelProvider;

//import com.sun.corba.se.spi.oa.OAInvocationInfo;

public class HomePanel extends JPanel {
	Image icon = new ImageIcon(getClass().getResource("HOME_PANEL.jpg")).getImage();
	
	HomeFrame homeFrame;
    AudioClip clip;
	public HomePanel(HomeFrame hf) throws Exception  , IllegalAccessException 
	{
		homeFrame = hf;
		setLayout(null);
	}

	@Override
	protected void paintComponent(Graphics arg0) {
		super.paintComponent(arg0);
		arg0.drawImage(icon, 0, 0, this);
	}
}
