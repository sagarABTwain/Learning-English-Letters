
//import javax.swing.JLabel;

//import java.awt.Component;
//import java.awt.FlowLayout;
//import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;

//import javax.swing.ButtonGroup;
//import javax.swing.JCheckBox;
//import javax.swing.JComboBox;
//import javax.swing.JFrame;
//import javax.swing.JList;
//import javax.swing.JMenu;
//import javax.swing.JMenuBar;
// javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import javax.swing.Icon;
//import javax.swing.event.ListSelectionEvent;
//import javax.swing.event.ListSelectionListener;
//import javax.swing.event.MenuEvent;
//
//import javax.script.*;
//import java.awt.*;
//import javax.swing.event.*;
//
//import org.omg.CORBA.PUBLIC_MEMBER;
//
//import java.awt.event.*;
//import java.util.Random;

import com.sun.accessibility.internal.resources.accessibility;
import com.sun.prism.paint.Color;


public class PrimaryEnglish extends JPanel {
	
	Image background=new ImageIcon(getClass().getResource("HOME_PANEL.jpg")).getImage();
    HomeFrame homeframe;
	public Examination examination;
	Random random=new Random();
	public PrimaryEnglish(HomeFrame hf) throws Exception  , IllegalAccessException
	{
		  this.homeframe=hf;
		   setLayout(null);
	}
	@Override
	protected void paintComponent(Graphics arg0) {
		super.paintComponent(arg0);
		arg0.drawImage(background, 0, 0, this);
	}

}
	


