
public class Main {

	public static void main(String[] args) throws IllegalAccessException, Exception ,ClassCastException
	{
			new HomeFrame();
		
	}

}