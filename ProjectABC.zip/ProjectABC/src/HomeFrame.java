//import java.awt.BorderLayout;
import java.awt.CardLayout;
//import java.awt.Color;
//import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
//import java.awt.event.ItemEvent;
//import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
//import java.awt.event.MouseListener;

import javax.swing.Icon;
import javax.swing.ImageIcon;
//import javax.swing.JButton;
import javax.swing.JFrame;
//import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JRootPane;
//import javax.swing.UIManager;
//import javax.swing.UIManager.LookAndFeelInfo;
//import javax.swing.event.MenuEvent;
//import javax.swing.event.MenuListener;

//import javax.swing.JLabel;


//import java.awt.Image;
//
//import javax.swing.ButtonGroup;
//import javax.swing.JCheckBox;
//import javax.swing.JComboBox;
//import javax.swing.JFrame;
//import javax.swing.JList;
//import javax.swing.JMenu;
//import javax.swing.JMenuBar;
//import javax.swing.JMenuItem;
//import javax.swing.JPanel;
//import javax.swing.JRadioButton;
//import javax.swing.JRootPane;
//import javax.swing.JScrollPane;
//import javax.swing.JTextField;
//import javax.swing.JPasswordField;
//import javax.swing.JOptionPane;
//import javax.swing.JToolBar;
//import javax.swing.ListSelectionModel;

//import java.awt.event.ActionListener;
//import java.awt.event.ActionEvent;
//import java.awt.event.ItemEvent;
//import java.awt.event.ItemListener;
//
//import javax.swing.JButton;
//import javax.swing.ImageIcon;
//import javax.swing.Icon;
//import javax.swing.event.ListSelectionEvent;
//import javax.swing.event.ListSelectionListener;
//import javax.swing.event.MenuEvent;
//
//import javax.script.*;
//import java.awt.*;
//import javax.swing.event.*;
//
//import org.omg.CORBA.PUBLIC_MEMBER;
//
//import java.awt.event.*;
//import java.util.Random;
//
//import com.sun.accessibility.internal.resources.accessibility;


public class HomeFrame extends JFrame {
	public static String HOME_PANEL = "homePanel";
	public static String PRIMARY_ENGLISH="primaryEnglish";
	public static String CAPITAL_ENGLISH="capitalenglish";
	public static String EXAMINATION="examinationEnglish";
	public static String SMALL_ENGLISH="smallenglish";

	HomePanel homePanel;
	PrimaryEnglish primaryEnglish;
	CapitalEnglish capitalenglish;
	Examination examinationEnglish;
	smallEnglish smallenglish;
	
	public static int next=0;
	
	
	JMenuBar menuBar = new JMenuBar();
	JPanel mainPanel = new JPanel();
	CardLayout cardLayout = new CardLayout();
	JMenu homeMenu;
	JMenu englishPrimary;	
	JMenuItem capitalLetter;
	JMenuItem smallLetter;
	JMenuItem exam;
		
	public HomeFrame() throws Exception  , IllegalAccessException , ClassCastException
	{	
		setTitle("Home");
		setSize(900, 675);
		setUndecorated(true);

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationByPlatform(true);
		setLocationRelativeTo(null);
		setVisible(true);
		mainPanel.setLayout(cardLayout);
		
		getRootPane().setWindowDecorationStyle(JRootPane.FRAME);//Frame ar char pass layer golu asbe
		
		homePanel = new HomePanel(this);
		primaryEnglish=new PrimaryEnglish(this);
		capitalenglish=new CapitalEnglish(this);
		smallenglish=new smallEnglish(this);
		examinationEnglish=new Examination(this);
		
		
		
		mainPanel.add(homePanel, HomeFrame.HOME_PANEL);
		mainPanel.add(primaryEnglish,HomeFrame.PRIMARY_ENGLISH);	
		mainPanel.add(capitalenglish, HomeFrame.CAPITAL_ENGLISH);
		mainPanel.add(smallenglish,HomeFrame.SMALL_ENGLISH);
		mainPanel.add(examinationEnglish,HomeFrame.EXAMINATION);
		
		add(mainPanel);
		
	

		// Create Menu For Menu Bar/ami ekhane change koreci*/
	    homeMenu = new JMenu();
		JMenu menu = new JMenu("MMManu");
		
       //for back option
		//Icon homeIcon = new ImageIcon(HomeFrame.class.getResource("home.png"));
		Icon menuIcon = new ImageIcon(getClass().getResource("menuIcon.png"));
       //Menubar ar picture golu ai 2 line ar madame dekha jai
		//homeMenu.setIcon(homeIcon);
		menu.setIcon(menuIcon);
	

		// Create Menu Item For Menu
		englishPrimary = new JMenu("English");
		capitalLetter = new JMenuItem("Capital Letter");
		smallLetter = new JMenuItem("Small Letter");
		exam = new JMenuItem("Test");
		
		englishPrimary.add(capitalLetter);
		englishPrimary.addSeparator();
		englishPrimary.add(smallLetter);
		englishPrimary.addSeparator();
		englishPrimary.add(exam);
		
       // Menu bar ar menu item add korar jonno
		menu.add(englishPrimary);
		menu.addSeparator();
				
		// add in menu bar
		menuBar.add(homeMenu);
		menuBar.add(menu);
		setJMenuBar(menuBar);
		
		
    	homeMenu.addMouseListener(mouseClick);
		englishPrimary.addMouseListener(mouseClick);
		
		Thehandler handler=new Thehandler();
		capitalLetter.addActionListener(handler);
		smallLetter.addActionListener(handler);
		exam.addActionListener(handler);
		
		setVisible(true);//Main Frame visibility
		setResizable(false);//main Frame Full skin hobe true dele
		
	}
	private class Thehandler implements ActionListener //pora frame ar ActionLisner
	{

		@Override
		public void actionPerformed(ActionEvent event) {

		 if(capitalLetter==event.getSource())
			{
				setTitle("Capital Letter");
				show("capitalenglish");
			}
			else if(event.getSource()==smallLetter)
			{
				setTitle("Small Letter");
				show("smallenglish");
			}
			else if(event.getSource()==exam)
			{
				setTitle("Test");
				show("examinationEnglish");
			}
		}	
	}
	// aki mainframe ar pore mouse dorle onno item  ba onno kesu anar jonno
	MouseAdapter mouseClick=new MouseAdapter() {
		     public void mouseClicked(MouseEvent arg0) {
		    	 
		    if(homeMenu.isSelected())
		    { 
		    	show("homePanel");
		    }else if(englishPrimary.isSelected())
		    {
		    	show("primaryEnglish");
		    }   
		 }
	};
	
	public void show(String panelName){
		cardLayout.show(mainPanel, panelName);
	}
	  
}

