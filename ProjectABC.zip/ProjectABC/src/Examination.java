import java.applet.Applet;
import java.applet.AudioClip;
//import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;
//import javax.print.DocFlavor.URL;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

//import com.sun.prism.Image;

public class Examination extends JPanel {
	public Random random = new Random();
	HomeFrame homeframe;
	int i, j;

	JButton nextButton = new JButton("Next");
	JButton backButton = new JButton("Back");

	String x = null;
	int num;
	JButton alpabetButton[] = new JButton[100];
	JButton alpabetButton2[] = new JButton[100];
	Icon icon[] = new ImageIcon[100];
	char s;
	int t = 0;
	public int a[] = new int[100];
	public int c[] = new int[100];
	int check = 0;
	private JButton start = new JButton("Start");
	AudioClip clip;
	ImageIcon back1 = new ImageIcon(getClass()
			.getResource("HomeBackground.PNG"));
	ImageIcon back2 = new ImageIcon(getClass().getResource(
			"ALphabetBackground.jpg"));
	JPanel panel1 = new JPanel() {
		protected void paintComponent(Graphics arg0) {
			super.paintComponent(arg0);
			arg0.drawImage(back1.getImage(), 0, 0, 900, 400, this);
		}
	};
	JPanel panel2 = new JPanel();

	public Examination(HomeFrame hf) {
		this.homeframe = hf;

		setLayout(null);

		panel1.setLayout(new GridBagLayout());

		panel1.setBounds(0, 0, 900, 400);

		panel2.setBounds(0, 400, 900, 300);

		panel2.setLayout(null);

		nextButton.setBounds(780,155, 100, 40);
		panel2.add(nextButton);

		backButton.setBounds(5, 155, 100, 40);
		panel2.add(backButton);

		int n = HomeFrame.next;
		//System.out.println(n);/*Ekhane index no. show korle bujha jabe kontar pore ki asbe*/

		int l = 5;
		if (HomeFrame.next == 20) {
			l = 6;
		}

		for (i = n; i < n + l; i++) {
			num = n + random.nextInt(l);
			for (j = n; j < i;) {

				if (a[j] == num) {
					num = n + random.nextInt(l);
					j = n;
				} else {

					j++;
				}
			}

			a[i] = num;

			c[a[i]] = i;

			s = 'A';
			s = (char) (s + a[i]);
			x = s + "_I.png";

			icon[i] = new ImageIcon(getClass().getResource(x));
			alpabetButton[i] = new JButton();

			alpabetButton[i].setIcon(icon[i]);

			panel1.add(alpabetButton[i]);

		}
		panel1.add(start);
		add(panel1);
		add(panel2);

		num = n;

		nextButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				try {
					if (HomeFrame.next == 20|| HomeFrame.next == 26 ) {
						HomeFrame.next = 26;
					} else if(HomeFrame.next==-5) {
						HomeFrame.next = HomeFrame.next + 10;
					}else 
					{
						HomeFrame.next = HomeFrame.next + 5;
					}
					Examination ex = new Examination(homeframe);
					homeframe.mainPanel.add(ex, HomeFrame.EXAMINATION);
					homeframe.show(HomeFrame.EXAMINATION);
				} catch (Exception ex) {
					JOptionPane.showMessageDialog(null, "Click Back",
							"Message", JOptionPane.ERROR_MESSAGE);
				}

			}
		});

		backButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				try {
					if (HomeFrame.next == 26) {
						HomeFrame.next =15 ;
					}
					else{
						HomeFrame.next = HomeFrame.next - 5;
					}
					Examination ex = new Examination(homeframe);
					homeframe.mainPanel.add(ex, HomeFrame.EXAMINATION);
					homeframe.show(HomeFrame.EXAMINATION);
				}
				catch (Exception ex) {
					JOptionPane.showMessageDialog(null, "Click Next",
							"Message", JOptionPane.ERROR_MESSAGE);
				}

			}
		});

		start.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent arg0) {
				if (check == 0) {
					s = (char) ('A' + num);
					x = "Audio_" + s + ".wav";
					java.net.URL url = getClass().getResource(x);
					clip = Applet.newAudioClip(url);
					clip.play();
					num++;
				}

				check = 1;

			}
		});

		Thehandler handler = new Thehandler();
		for (i = n; i < n + l; i++) {
			alpabetButton[i].addActionListener(handler);
		}	

	}

	private class Thehandler implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent arg0) {

			try {

				if (alpabetButton[c[num - 1]] == arg0.getSource() && check == 1) {
					alpabetButton[c[num - 1]].setLocation(110 + t, 40);

					panel2.add(alpabetButton[c[num - 1]]);

					t = t + 110;
					check = 0;

				} else if (check == 1) {
					JOptionPane.showMessageDialog(null, "Wrong", "Message",
							JOptionPane.ERROR_MESSAGE);
				}

				else {
					JOptionPane.showMessageDialog(null, "CLick Start",
							"Message", JOptionPane.ERROR_MESSAGE);
				}

			} catch (Exception e) {
				JOptionPane.showMessageDialog(null, "CLick Start", "Message",
						JOptionPane.ERROR_MESSAGE);
			}

		}
	}
}
